
<?php
function sumaDigitos($n) {
    if ($n < 10) {
        return $n;
    } else {
        return ($n % 10) + sumaDigitos(intval($n / 10));
    }
}
echo sumaDigitos(1234);