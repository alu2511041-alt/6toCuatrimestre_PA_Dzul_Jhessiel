<?php
session_start();

require_once("Conexion.php");

$mensaje = "";
$totalPedido = "";

if(isset($_POST['tomar_pedido'])){

    $mesa = trim($_POST['mesa']);
    $cliente = trim($_POST['cliente']);
    $total = trim($_POST['total']);
    $fecha = trim($_POST['fecha']);

    if(empty($mesa)){
        $mensaje = "La mesa es obligatoria";
    }elseif(empty($cliente)){
        $mensaje = "El cliente es obligatorio";
    }elseif(!is_numeric($total) || $total <= 0){
        $mensaje = "El total debe ser un número positivo";
    }elseif(strtotime($fecha) === false){
        $mensaje = "La fecha no es válida";
    }else{

        $sql = $conexion->prepare(
            "INSERT INTO pedidos (mesa, cliente, total, fecha)
             VALUES (?, ?, ?, ?)"
        );

        $sql->bind_param(
            "ssds",
            $mesa,
            $cliente,
            $total,
            $fecha
        );

        if($sql->execute()){
            $mensaje = "Pedido registrado correctamente";
        }else{
            $mensaje = "Error: " . $sql->error;
        }

        $sql->close();
    }
}


if(isset($_POST['agregar_platillo'])){

    $pedido_id = trim($_POST['pedido_id']);
    $nombre_platillo = trim($_POST['nombre_platillo']);
    $precio = trim($_POST['precio']);
    $cantidad = trim($_POST['cantidad']);

    $verificar = $conexion->prepare(
        "SELECT id FROM pedidos WHERE id = ?"
    );

    $verificar->bind_param("i", $pedido_id);
    $verificar->execute();

    $resultado = $verificar->get_result();

    if($resultado->num_rows == 0){

        $mensaje = "El pedido no existe";

    }else{

        $sql = $conexion->prepare(
            "INSERT INTO detalle_pedido
            (pedido_id, nombre_platillo, precio, cantidad)
            VALUES (?, ?, ?, ?)"
        );

        $sql->bind_param(
            "isdi",
            $pedido_id,
            $nombre_platillo,
            $precio,
            $cantidad
        );

        if($sql->execute()){
            $mensaje = "Platillo agregado correctamente";
        }else{
            $mensaje = "Error: " . $sql->error;
        }

        $sql->close();
    }

    $verificar->close();
}


if(isset($_POST['calcular_total'])){

    $pedido_id = trim($_POST['pedido_id']);

    $sql = $conexion->prepare(
        "SELECT SUM(precio * cantidad) AS total
         FROM detalle_pedido
         WHERE pedido_id = ?"
    );

    $sql->bind_param("i", $pedido_id);

    if($sql->execute()){

        $resultado = $sql->get_result();
        $fila = $resultado->fetch_assoc();

        if($fila['total'] != null){
            $totalPedido = number_format($fila['total'], 2);
        }else{
            $totalPedido = "0.00";
        }

    }else{

        $mensaje = "Error al calcular total";

    }

    $sql->close();
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Sistema Restaurante</title>

</head>
<body>

<h1>Bienvenido al Restaurante</h1>

<?php
if(!empty($mensaje)){
    echo "<p class='mensaje'>$mensaje</p>";
}
?>

<h2>Registrar Pedido</h2>

<form method="POST">

    <input type="text"
           name="mesa"
           placeholder="Número de mesa"
           required>

    <br><br>

    <input type="text"
           name="cliente"
           placeholder="Nombre del cliente"
           required>

    <br><br>

    <input type="number"
           step="0.01"
           name="total"
           placeholder="Total del pedido"
           required>

    <br><br>

    <input type="date"
           name="fecha"
           required>

    <br><br>

    <button type="submit" name="tomar_pedido">
        Registrar Pedido
    </button>

</form>

<hr>

<h2>Agregar Platillo</h2>

<form method="POST">

    <input type="number"
           name="pedido_id"
           placeholder="ID del Pedido"
           required>

    <br><br>

    <input type="text"
           name="nombre_platillo"
           placeholder="Nombre del Platillo"
           required>

    <br><br>

    <input type="number"
           step="0.01"
           name="precio"
           placeholder="Precio"
           required>

    <br><br>

    <input type="number"
           name="cantidad"
           placeholder="Cantidad"
           required>

    <br><br>

    <button type="submit" name="agregar_platillo">
        Agregar Platillo
    </button>
</form>

<hr>

<h2>Calcular Total del Pedido</h2>

<form method="POST">

    <input type="number"
           name="pedido_id"
           placeholder="ID del Pedido"
           required>

    <br><br>

    <button type="submit" name="calcular_total">
        Calcular Total
    </button>

</form>

<?php
if($totalPedido !== ""){
    echo "<p><strong>Total del Pedido: $".$totalPedido."</strong></p>";
}
?>

<hr2>Pedidos Registrados</h2>
<?php
$sql = "SELECT * FROM pedidos";
$resultado = $conexion->query($sql);
if($resultado->num_rows > 0){
    while($fila = $resultado->fetch_assoc()){
        echo "<p><strong>ID:</strong> " . $fila['id'] . " - <strong>Mesa:</strong> " . $fila['mesa'] . " - <strong>Cliente:</strong> " . $fila['cliente'] . " - <strong>Total:</strong> $" . number_format($fila['total'], 2) . " - <strong>Fecha:</strong> " . $fila['fecha'] . "</p>";
    }
}else{
    echo "<p>No hay pedidos registrados.</p>";
}
$conexion->close();
?>
</body>
</html>