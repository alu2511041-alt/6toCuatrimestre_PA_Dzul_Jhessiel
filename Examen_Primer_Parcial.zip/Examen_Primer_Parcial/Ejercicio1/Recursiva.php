<?php
function contar_digitos($numero) {
    if ($numero < 10) {
        return 1;
    } else {
        return 1 + contar_digitos(intval($numero / 10));
    }
}
echo contar_digitos(12345); 