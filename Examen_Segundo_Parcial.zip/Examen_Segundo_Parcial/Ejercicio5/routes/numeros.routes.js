const express = require("express");
const router = express.Router();

router.get("/pares", (req, res) => {
    const n = parseInt(req.query.n);

    if (isNaN(n)) {
        return res.status(400).json({
            mensaje: "Debe enviar el parámetro n"
        });
    }

    let pares = [];

    for (let i = 2; i <= n; i += 2) {
        pares.push(i);
    }

    res.json({
        hasta: n,
        numeros_pares: pares
    });
});

module.exports = router;