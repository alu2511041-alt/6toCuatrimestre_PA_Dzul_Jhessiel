const express = require("express");
const app = express();

const numerosRoutes = require("./routes/numeros.routes");

app.use("/numeros", numerosRoutes);

app.listen(3000, () => {
    console.log("Servidor iniciado en el puerto 3000");
});