const express = require("express");
const router = express.Router();
const db = require("../config/db");

router.get("/buscar", (req, res) => {

    const texto = req.query.texto;

    if (!texto) {
        return res.status(400).json({
            mensaje: "Falta el parámetro texto"
        });
    }

    const sql = `
        SELECT *
        FROM tareas
        WHERE titulo LIKE ?
           OR descripcion LIKE ?
    `;

    db.query(sql, [`%${texto}%`, `%${texto}%`], (err, resultados) => {

        if (err) {
            return res.status(500).json(err);
        }

        res.json(resultados);

    });

});

module.exports = router;