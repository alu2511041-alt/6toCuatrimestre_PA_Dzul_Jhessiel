const mysql = require("mysql2");

const conexion = mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "messi123",
    database: "todo_app"
});

conexion.connect((err) => {
    if (err) {
        console.error(err);
    } else {
        console.log("Conectado a MySQL");
    }
});

module.exports = conexion;