const express = require("express");
const app = express();

const tareasRoutes = require("./routes/tareas.routes");

app.use(express.json());

app.use("/tareas", tareasRoutes);

app.listen(3000, () => {
    console.log("Servidor iniciado en el puerto 3000");
});