const express = require("express");
const router = express.Router();

router.get("/", (req, res) => {

    if (req.query.fecha !== undefined) {

        const ahora = new Date();

        res.json({
            fecha: ahora.toLocaleDateString(),
            hora: ahora.toLocaleTimeString()
        });

    } else {

        res.status(400).json({
            mensaje: "Debe enviar el parámetro 'fecha'"
        });

    }

});

module.exports = router;