const express = require("express");
const app = express();

const fechaRoutes = require("./routes/fecha.routes");

app.use("/fecha", fechaRoutes);

app.listen(3000, () => {
    console.log("Servidor iniciado en el puerto 3000");
});