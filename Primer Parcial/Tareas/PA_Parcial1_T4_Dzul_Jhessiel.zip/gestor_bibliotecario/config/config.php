<?php
    $db_host = "localhost";
    $db_user = "root";
    $db_pass = "messi123";
    $db_name = "gestor_biblioteca";
