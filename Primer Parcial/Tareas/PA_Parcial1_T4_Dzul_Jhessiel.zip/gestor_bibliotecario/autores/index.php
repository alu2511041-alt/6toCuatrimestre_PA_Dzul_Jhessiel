<?php
    require_once "../config/connection.php";
?>
<?php include_once "../includes/header.php"; ?>

<div class="page-header">
    <h1><i class="fas fa-users"></i> Autores</h1>
    <a href="create.php" class="btn btn-primary">
        <i class="fas fa-plus"></i> Nuevo Autor
    </a>
</div>

<?php if (isset($_GET["success"])): ?>
    <div class="alert alert-success">
        <i class="fas fa-check-circle"></i>
        <?= htmlspecialchars($_GET["success"]) ?>
    </div>
<?php elseif (isset($_GET["error"])): ?>
    <div class="alert alert-danger">
        <i class="fas fa-exclamation-circle"></i>
        <?= htmlspecialchars($_GET["error"]) ?>
    </div>
<?php endif; ?>

<div class="table-container">
    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Nombre</th>
                <th>Apellido</th>
                <th>Nacionalidad</th>
                <th>Fecha de Nacimiento</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
          <?php
$sql = "SELECT * FROM autores ORDER BY id DESC";
$result = $conn->query($sql);
if ($result && $result->num_rows > 0):
while ($autor = $result->fetch_assoc()):
?>
<tr>
 <td><?= $autor["id"] ?></td>
 <td><?= htmlspecialchars($autor["nombre"]) ?></td>
 <td><?= htmlspecialchars($autor["apellido"]) ?></td>
 <td><?= htmlspecialchars($autor["nacionalidad"]) ?></td>
 <td><?= htmlspecialchars($autor["fecha_nacimiento"]) ?></td>
 <td>
 <a href="edit.php?id=<?= $autor['id'] ?>" class="btn btn-warning">
 <i class="fas fa-edit"></i> Editar
 </a>
 <a href="delete.php?id=<?= $autor['id'] ?>"
 class="btn btn-danger"
 onclick="return confirm('¿Deseas eliminar este autor?')">
 <i class="fas fa-trash"></i> Eliminar
 </a>
 </td>
</tr>
<?php
endwhile;
else:
?>
<tr>
 <td colspan="6">No hay autores registrados</td>
</tr>
<?php endif; ?>

        </tbody>
    </table>
</div>

<?php include_once "../includes/footer.php"; ?>
